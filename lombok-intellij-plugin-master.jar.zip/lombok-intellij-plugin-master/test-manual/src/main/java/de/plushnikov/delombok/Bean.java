package de.plushnikov.delombok;

import lombok.Data;

@Data
public class Bean {
  private final int id;
  private final String string;
}
