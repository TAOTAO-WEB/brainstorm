package de.plushnikov.constructor;

@lombok.NoArgsConstructor(force = true)
public class NoArgsForced {
  final int x;
  final double y;
  final char c;
  final boolean b;
  final float f;
  final String s;
  byte z;

}