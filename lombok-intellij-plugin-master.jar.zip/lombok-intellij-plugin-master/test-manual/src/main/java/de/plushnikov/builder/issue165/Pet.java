package de.plushnikov.builder.issue165;

import lombok.Data;

@Data
public class Pet {
  private String species;
  private String name;
}
