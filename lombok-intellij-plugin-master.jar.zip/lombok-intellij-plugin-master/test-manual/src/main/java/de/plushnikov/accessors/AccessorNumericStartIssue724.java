package de.plushnikov.accessors;

import lombok.Getter;
import lombok.experimental.Accessors;

@Accessors(prefix = "m")
public class AccessorNumericStartIssue724 {
  @Getter
  private float m3Titanic;
}

