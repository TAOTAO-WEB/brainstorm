package de.plushnikov.constructor;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NoArgsConstructorClass {
  private int intProperty;

  private float floatProperty;

  private String stringProperty;
}
