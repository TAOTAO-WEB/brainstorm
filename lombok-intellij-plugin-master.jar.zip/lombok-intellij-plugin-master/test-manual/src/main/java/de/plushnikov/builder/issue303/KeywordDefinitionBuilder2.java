package de.plushnikov.builder.issue303;

public class KeywordDefinitionBuilder2 extends KeywordDefinition.KeywordDefinitionBuilder {

}

