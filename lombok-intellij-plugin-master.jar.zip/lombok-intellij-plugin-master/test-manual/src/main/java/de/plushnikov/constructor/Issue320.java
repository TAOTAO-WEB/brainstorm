package de.plushnikov.constructor;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class Issue320 {
  private String abcd;
  private int index;

}
