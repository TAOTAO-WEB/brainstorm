package de.plushnikov.intellij.plugin.action.lombok;

public class LombokSetterAction extends BaseLombokAction {

  public LombokSetterAction() {
    super(new LombokSetterHandler());
  }

}
