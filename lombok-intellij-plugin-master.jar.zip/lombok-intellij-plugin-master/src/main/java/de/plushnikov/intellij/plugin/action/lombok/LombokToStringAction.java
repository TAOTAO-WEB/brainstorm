package de.plushnikov.intellij.plugin.action.lombok;

public class LombokToStringAction extends BaseLombokAction {

  public LombokToStringAction() {
    super(new LombokToStringHandler());
  }

}
