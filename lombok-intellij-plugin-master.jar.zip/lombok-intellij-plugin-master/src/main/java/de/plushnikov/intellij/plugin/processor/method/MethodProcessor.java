package de.plushnikov.intellij.plugin.processor.method;

import de.plushnikov.intellij.plugin.processor.Processor;

interface MethodProcessor extends Processor {
}