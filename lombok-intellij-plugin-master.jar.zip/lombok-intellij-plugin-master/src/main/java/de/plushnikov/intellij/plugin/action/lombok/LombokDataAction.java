package de.plushnikov.intellij.plugin.action.lombok;

public class LombokDataAction extends BaseLombokAction {

  public LombokDataAction() {
    super(new LombokDataHandler());
  }

}
