package de.plushnikov.intellij.plugin.action.lombok;

public class LombokLoggerAction extends BaseLombokAction {

  public LombokLoggerAction() {
    super(new LombokLoggerHandler());
  }

}
