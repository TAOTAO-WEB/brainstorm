package de.plushnikov.intellij.plugin.processor.clazz;

import de.plushnikov.intellij.plugin.processor.Processor;

/**
 * @author Plushnikov Michail
 */
interface ClassProcessor extends Processor {
}
