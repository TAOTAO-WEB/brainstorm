package de.plushnikov.intellij.plugin.processor.field;

import de.plushnikov.intellij.plugin.processor.Processor;

/**
 * @author Plushnikov Michail
 */
interface FieldProcessor extends Processor {
}
