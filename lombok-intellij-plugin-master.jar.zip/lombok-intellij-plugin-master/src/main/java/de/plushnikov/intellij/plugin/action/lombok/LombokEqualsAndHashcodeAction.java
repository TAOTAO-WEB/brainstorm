package de.plushnikov.intellij.plugin.action.lombok;

public class LombokEqualsAndHashcodeAction extends BaseLombokAction {

  public LombokEqualsAndHashcodeAction() {
    super(new LombokEqualsAndHashcodeHandler());
  }

}
