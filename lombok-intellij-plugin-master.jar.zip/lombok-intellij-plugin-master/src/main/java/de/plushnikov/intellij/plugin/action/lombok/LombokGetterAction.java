package de.plushnikov.intellij.plugin.action.lombok;

public class LombokGetterAction extends BaseLombokAction {

  public LombokGetterAction() {
    super(new LombokGetterHandler());
  }

}
