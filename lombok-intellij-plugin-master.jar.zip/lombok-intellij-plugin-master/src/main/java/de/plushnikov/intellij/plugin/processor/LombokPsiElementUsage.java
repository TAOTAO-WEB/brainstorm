package de.plushnikov.intellij.plugin.processor;

public enum LombokPsiElementUsage {
  NONE, USAGE, READ, WRITE, READ_WRITE
}
