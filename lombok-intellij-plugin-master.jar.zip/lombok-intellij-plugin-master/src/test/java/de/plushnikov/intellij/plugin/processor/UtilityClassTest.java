package de.plushnikov.intellij.plugin.processor;

import de.plushnikov.intellij.plugin.AbstractLombokParsingTestCase;

public class UtilityClassTest extends AbstractLombokParsingTestCase {

  public void testUtilityclass$UtilityClassPlain() {
    doTest(true);
  }
}
