package de.plushnikov.intellij.plugin.lombokconfig;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.UserDataHolderEx;

public interface MyProject extends Project, UserDataHolderEx {
}
